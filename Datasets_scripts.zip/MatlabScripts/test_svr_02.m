clear;
clc;

% addpath('/Users/yathee-itphd/Documents/Doc for Prof/SVM');
addpath('/Users/yathee-itphd/Documents/workspace/libsvm-3.21/matlab');


%% Data set
N = 2483;    % N training instances
nv = 5;     % nv features
% 

[y ,x ] = libsvmread ('test_train_02102017_wrk3.scale');


%% Training and testing model
% Training with 50% of data
tic;
%model = svmtrain(y(1:N/2),x(1:N/2,:),['-s 3 -t 2 -g ' num2str(0.0078125) ' -c ' num2str(32) ' -p ' num2str(29.63)]);
model = svmtrain(y(1:1200),x(1:1200,:),['-s 3 -t 2 -g ' num2str(0.0078125) ' -c ' num2str(32)]);
%model = svmtrain(y(1:1500),x(1:1500,:),['-s 3 -t 2 -g ' num2str(0.5) ' -c ' num2str(0.5)]);
%model = svmtrain(y(1:N/2),x(1:N/2,:),['-s 3 -t 2 -g ' num2str(0.0078125) ' -c ' num2str(0.03125)]);
toc
% Testing with the rest data (50 %)
tic;
zz=svmpredict(y(1201:end),x(1201:end,:),model);toc
tmp = corrcoef(zz, y(1201:end));


% Get the w and b of model
w = model.SVs' * model.sv_coef;
b = -model.rho;
% 


%% Predict a new set of data

[y_pred, x_pred] = libsvmread ('test_train_10102017_wrk3.scale');
zz_pred = svmpredict ( y_pred, x_pred, model );
tmp2 = corrcoef(zz_pred, y_pred);

