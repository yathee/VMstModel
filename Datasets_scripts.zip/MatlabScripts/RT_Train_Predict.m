%Read the data %
delimiterIn = ',';
headerlinesIn = 1;
InA = importdata('test_Train_ANN_RT_wrk3.csv',delimiterIn,headerlinesIn);
VMStartupTime = InA.data(:,1);
ImageSize = InA.data(:,2);
CPUUtilization = InA.data(:,3);
MemoryUtilization = InA.data(:,4);
NetworkUtil = InA.data(:,5);
NumberReq = InA.data(:,6);

%Prep data for training 
Xtrain = horzcat( ImageSize(1:1200),CPUUtilization(1:1200),MemoryUtilization(1:1200),NetworkUtil(1:1200),NumberReq(1:1200));

%Xtrain = transpose(Xtrain);

Ytrain = VMStartupTime(1:1200);

% Test data

Xtest = horzcat( ImageSize(1201:end),CPUUtilization(1201:end),MemoryUtilization(1201:end),NetworkUtil(1201:end),NumberReq(1201:end));
Yact = VMStartupTime(1201:end);



% Training 
tr = fitrtree(Xtrain,Ytrain);

% Testing 

Ytest = predict(tr ,Xtest);
err_test = Yact - Ytest;


% Data preparations for the Prediction 

InAP = importdata('test_Predict_ANN_RT_wrk3.csv',delimiterIn,headerlinesIn);
VMSt = InAP.data(:,1);
ISize = InAP.data(:,2);
CPUUtil = InAP.data(:,3);
MemUtil = InAP.data(:,4);
NetUtil = InAP.data(:,5);
NumReq = InAP.data(:,6);


Xpred = horzcat( ISize,CPUUtil,MemUtil,NetUtil,NumReq);
Yactual = VMSt;

% Prediction 

Ypred = predict(tr ,Xpred);
err_pred = Yactual - Ypred;

