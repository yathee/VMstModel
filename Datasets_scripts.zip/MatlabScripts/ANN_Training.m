%Read the data %
delimiterIn = ',';
headerlinesIn = 1;
InA = importdata('test_Train_ANN_RT_wrk3.csv',delimiterIn,headerlinesIn);
VMStartupTime = InA.data(:,1);
ImageSize = InA.data(:,2);
CPUUtilization = InA.data(:,3);
MemoryUtilization = InA.data(:,4);
NetworkUtil = InA.data(:,5);
NumberReq = InA.data(:,6);

%Prep data for training 
Xtrain = horzcat( ImageSize(1:1200),CPUUtilization(1:1200),MemoryUtilization(1:1200),NetworkUtil(1:1200),NumberReq(1:1200));
%Xtrain = horzcat( ImageSize,CPUUtilization,MemoryUtilization,NetworkUtil,NumberReq);

Xtrain = transpose(Xtrain);

Ytrain = VMStartupTime(1:1200);
%Ytrain = VMStartupTime;
Ytrain = transpose(Ytrain);

% Create feedforward network with hidden layer 

net = feedforwardnet([10]);
net.layers{1}.transferFcn = 'purelin';

% set early stopping parameters
net.divideParam.trainRatio = 1.0; % training set [%]
net.divideParam.valRatio = 0.0; % validation set [%]
net.divideParam.testRatio = 0.0; % test set [%]
% train a neural network
net.trainParam.epochs = 200;
[net,tr] = train(net,Xtrain,Ytrain);

% Test the net
Xtest = horzcat( ImageSize(1201:end),CPUUtilization(1201:end),MemoryUtilization(1201:end),NetworkUtil(1201:end),NumberReq(1201:end));
Xtest = transpose(Xtest);
Ytest = VMStartupTime(1201:end);
Ytest = transpose(Ytest);

Ytestpred = net(Xtest);

err_test = Ytest - Ytestpred;

YTpred = transpose(Ytestpred);
YTtest = transpose(Ytest);
XTtest = transpose(Xtest);


% Load the dataset for prediction 

InAP = importdata('test_Predict_ANN_RT_wrk3.csv',delimiterIn,headerlinesIn);
VMSt = InAP.data(:,1);
ISize = InAP.data(:,2);
CPUUtil = InAP.data(:,3);
MemUtil = InAP.data(:,4);
NetUtil = InAP.data(:,5);
NumReq = InAP.data(:,6);

%Prep data for Prediction 
Xpred = horzcat( ISize,CPUUtil,MemUtil,NetUtil,NumReq);
%Xtrain = horzcat( ImageSize,CPUUtilization,MemoryUtilization,NetworkUtil,NumberReq);

Xpred = transpose(Xpred);

Yactual = VMSt;

Ypred = net(Xpred);

err_pred = Yactual - (transpose(Ypred));

YTpred = transpose(Ypred);
YTactual = transpose(Yactual);
XTpred = transpose(Xpred);

tmp = corrcoef ( YTactual,YTpred)





